""" 用python设计第一个游戏"""
i = 1
while i <= 9:
    j = 1
    while j <= i:
        print(i,end='')
        print('*',end='')
        print(j,end='')
        print('=',end='')
        print(i*j,end=' ')
        j+=1
    print()
    i+=1        
