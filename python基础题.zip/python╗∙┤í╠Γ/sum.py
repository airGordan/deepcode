i = 1
s = 0
while i<10087:
    s+=i
    i+=1
print("1+2+...+10086 =",s)

