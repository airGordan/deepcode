"""等腰三角形"""

a = input("请输入三角形的高：")
b = int(a)
m = 1
while (m <= b):
    n = 1
    while (n <= (2*b - 1)):
        if (abs(n - b) < m):
            print("*",end='')
        else :
            print(" ",end='')
        n=n+1            
    m=m+1
    print()
                      

