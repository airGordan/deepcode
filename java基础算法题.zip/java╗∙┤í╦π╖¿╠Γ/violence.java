package calculate;
import java.util.Arrays;
/*
����������n������С�����˳�������������abcde/fghij = n�ı���ʽ��
����a~jǡ��Ϊ����0~9��һ�����У�2��n��79.��
�������룺
62
���������
79546/01283 = 62
94736/01528 = 62
*/
public class violence {
	public static void main(String[] args) {
		int n = 62;
        int f,g,h,i,j;
        for (f = 0; f < 10; f++) {
            for (g = 0; g < 10; g++) {
                if (g == f) {
                    continue;
                }
                for (h = 0; h < 10; h++) {
                    if (h ==g || h == f) {
                        continue;
                    }
                    for (i = 0; i < 10; i++) {
                        if (i == h|| i == g || i == f) {
                            continue;
                        }
                        for (j = 0; j < 10; j++) {
                            if (j == i || j == h|| j == g || j==f) {
                                continue;
                            }
                            int dvisor = f*10000+g*1000+h*100+i*10+j;
                            int dividend = dvisor*n;
                            //�ж��Ƿ����
                            if (dividend > 99999) {
                                continue;
                            }
                            isCheck(dvisor, dividend);//�ж��Ƿ����           
                            int aa = dvisor/10000;
                            int bb = dvisor/1000-aa*10;
                            int cc = dvisor/100-aa*100-bb*10;
                            int dd = dvisor/10-aa*1000-bb*100-cc*10;
                            int ee = dvisor-aa*10000-bb*1000-cc*100-dd*10;
                            int ff = dvisor/1000;
                            int gg = dvisor/100-ff*10;
                            int hh = dvisor/10-ff*100-gg*10;
                            int ii = dvisor-ff*1000-gg*100-hh*10;
                            int[] mm = {aa,bb,cc,dd,ee,ff,gg,hh,ii,};
                            Arrays.sort(mm);
                            boolean xx =true;
                            if(mm[8]==0) {
                            	xx=false;
                            }
                            for(i=0;i<8;i++) {
                            	if(mm[i]==mm[i+1]||mm[i]==0) {
                            		xx = false;
                            	}
                            }
                            if(xx) {
                            	System.out.println(dvisor*n+"/"+dvisor+"="+n);
                            }
                        }
                    }
                }
                
            }
        }

    }

    private static boolean isCheck(int dvisor,int dividend){
        String temp1 = String.valueOf(dvisor);
        String temp2 = String.valueOf(dividend);
        if (temp1.length() == 4) {//����5λ��ǰ�油0
            temp1 = "0"+temp1;
        }
        if (temp2.length() == 4) {
            temp2 = "0"+temp2;
        }
        String str = temp1+temp2;
        char[] arr = str.toCharArray();
        Arrays.sort(arr);
        for (int i = 0; i < arr.length; i++) {//ͨ���ַ����������бȽ�
            if (arr[i] != '0'+i) {
                return false;
            }
        }
        return true;
    }
}


