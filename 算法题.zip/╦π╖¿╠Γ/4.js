for(let i=1;i<=9;i++){
    let re='';
    for(let j=1;j<=i;j++){
        re+=`${i}*${j}=${i*j}\t`;  
    }
    console.log(re);
}
