var s = 0;
for(var i = 1;i < 10087;i++){
	s = s + i;
}
console.log(s);