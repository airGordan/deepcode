//a是三角的高
function f(a){
	let re = '';
	for(let i=1;i<=a;i++){
		for(let m=1;m<=2*a-1;m++){
			if(Math.abs(a-m)<i){
				console.log(re+=`${'*'}`);
			}
			else{
				console.log(re+=`${' '}`);
			}
		}
			console.log(re+=`\n`);
	}
}
f(5);